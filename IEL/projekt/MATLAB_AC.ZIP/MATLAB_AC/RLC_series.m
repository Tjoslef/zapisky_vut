function RLC_series
%  clc
% clear
%  close all

global U0 R L C omega
U0=10;
% u=U0*sin(omega*t)
R = 10;
L = 10^-2;
C = 10^-1;
% omega=31.622776601683796;
% Resonance
f_res=1/(2*pi*sqrt(L*C));
omega_res=1/sqrt(L*C);

fprintf('\n****RLC in series****\n')
fprintf('\nResonance: omega=%g rad/s, f=%g Hz\n', omega_res, f_res);

omega=omega_res;

fprintf('Parameters: |U0|= %g V, R= %g Ohms, L= %g H, C = %g F, omega= %g rad/s\n',U0,R,L,C,omega);


x0=[0; 0];
tmax=5;
odeSolve=ode15s(@f_dxdt,[0,tmax],x0); %[uc, i]
% odeSolve=ode45(@f_dxdt,[0,tmax],x0); %[uc, i] 

figure
subplot(3,1,1)
plot(odeSolve.x, odeSolve.y(2,:)*R,'-',odeSolve.x, odeSolve.y(2,:),'-')
title(['Resistor (\omega=', num2str(omega),'rad/s)'])
grid on
legend('voltage u_R', 'current i')

%UL=U-UR-UC
subplot(3,1,2)
% plot(odeSolve.x, U0*sin(omega*odeSolve.x)-odeSolve.y(2,:)*R-odeSolve.y(1,:),'-',odeSolve.x, odeSolve.y(2,:),'-')
plot(odeSolve.x, U0*sin(omega*odeSolve.x)-odeSolve.y(2,:)*R-odeSolve.y(1,:),'-')
title('Inductor')
grid on
% legend('voltage u_L', 'current i')
legend('voltage u_L')

subplot(3,1,3)
% plot(odeSolve.x, odeSolve.y(1,:),'-',odeSolve.x, odeSolve.y(2,:),'-')
plot(odeSolve.x, odeSolve.y(1,:),'-')
title('Capacitor')
grid on
% legend('voltage u_C', 'current i')
legend('voltage u_C')




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% **** Steady state analysis *****
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Reactances
XL=omega*L;
XC=1/(omega*C);


% Impedances
ZL=j*XL;
ZC=-j*XC;
Zekv=R+ZL+ZC;

% Amplitudes and phases
I0=U0/Zekv;
UR=I0*R;
UC=I0*ZC;
UL=I0*ZL;

fprintf('\n**** Steady state analysis *****\n');
fprintf('|I0|= %g , phase= %g, I0= %g %gj\n', abs(I0), angle(I0)*360/(2*pi), real(I0), imag(I0));
fprintf('|UR|= %g , phase= %g, UR= %g %gj\n', abs(UR), angle(UR)*360/(2*pi), real(UR), imag(UR));
fprintf('|UC|= %g , phase= %g, UC= %g %gj\n', abs(UC), angle(UC)*360/(2*pi), real(UC), imag(UC));
fprintf('|UL|= %g , phase= %g, UL= %g %gj\n', abs(UL), angle(UL)*360/(2*pi), real(UL), imag(UL));







%%%%%%%%% analytic solution %%%%%%%%%
% R = 200;
% L = 10^-2;
% C = 10^-6;
% omega=1000;
% A = 1980/2040.2;
% B = -2000/10201;
% C1 = 2*10^7/10201-198*10^4/2040.2;
% C2 = -B;

% t=[0:tmax/1000:tmax];
% uc=exp(-10^4*t).*(C1*t+C2)+A*sin(omega*t)+B*cos(omega*t);
% i = C*(-10^4*exp(-10^4*t).*(C1*t+C2)+exp(-10^4*t)*C1+A*1000*cos(omega*t)-B*1000*sin(omega*t));

%%%%%%%%%%%%%%%%%%

% figure
% plot(odeSolve.x, odeSolve.y(1,:),'o',t,uc)
% grid on
% title('voltage uc')
% legend('numerical solution', 'analytical solution')
% 
% 
% figure
% plot(odeSolve.x, odeSolve.y(2,:),'o',t,i)
% grid on
% title('current i')
% legend('numerical solution', 'analytical solution')









end


function dydt = f_dxdt(t,y)
% y = [uc i]
global U0 R L C omega
dydt = zeros(2,1);    % a column vector
dydt(1) =  y(2)/C;
dydt(2) =  (U0*sin(omega*t)-R*y(2)-y(1))/L;
end




% dx=0.001;
% x=[0:dx:10];%x_odeSolution];
% 
% int_f=0;
% for i=1:length(x)-1
%     int_f=int_f+1/2*dx*(f(x(i))+f(x(i+1)));
% 
% end
% 
% int_f
