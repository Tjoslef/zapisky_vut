% Thevenin example, AC circuit
%
%  |---L1------R2---|
%  R1      |        L2
%  |       |        |
%  u1      C        u2
%  |       |        |
%  -----------------

% parameters of el. circuit
% f=70; % [Hz]
% omega=2*pi*f; %[rad/s]
omega=1; %[rad/s] % f= 0.159154943091895
L1=1; %[H]
L2=1; %[H]
R1=2; %[ohm]
R2=2; %[ohm]
C=1;  %[F]


% u1=15*sin(omega*t) 
% u2=5*sin(omega*t)

% amplitudes of AC sources
U1=15; %[V]
U2=5; %[V]

% reactances
XL1=omega*L1;
XL2=omega*L2;
XC=1/(omega*C);

% impedances
ZL1=j*XL1;
ZL2=j*XL2;
ZC=-j*XC;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% computation Zi
Zi=(ZL1+R1)*(ZL2+R2)/(ZL1+R1+ZL2+R2)

% computation Ui
Zekv=ZL1+R1+ZL2+R2;
U12=U1-U2;
I=U12/Zekv;

Ui=U1-R1*I-I*ZL1

% computation IC
IC=Ui/(Zi+ZC)

% compute UC
UC=ZC*IC

fprintf('\n**** Steady state analysis - Thevenin *****\n');
fprintf('|IC|= %g , phase= %g�, I0= %g %gj\n', abs(IC), angle(IC)*360/(2*pi), real(IC), imag(IC));
fprintf('|UC|= %g , phase= %g�, UC= %g %gj\n', abs(UC), angle(UC)*360/(2*pi), real(UC), imag(UC));


%%%% Uzlova napeti %%%%%

UA=(U1*(ZL2+R2)*ZC+U2*(ZL1+R1)*ZC)/((ZL2+R2)*ZC+(ZL1+R1)*ZC+(ZL1+R1)*(ZL2+R2));

UC=UA;
IC=UC/ZC;

fprintf('\n**** Steady state analysis - Uzlova napeti *****\n');
fprintf('|IC|= %g , phase= %g�, I0= %g %gj\n', abs(IC), angle(IC)*360/(2*pi), real(IC), imag(IC));
fprintf('|UC|= %g , phase= %g�, UC= %g %gj\n', abs(UC), angle(UC)*360/(2*pi), real(UC), imag(UC));

