% Loop current example, AC circuit
%
%  |---L1-----R1---|
%  |               |
%  |-u1-C1---C2----|
%  |       |       |
%  |       L2      u2
%  |       |       |
%  |---R2-----C3---|

% parameters of el. circuit
f=70; % [Hz]
omega=2*pi*f; %[rad/s]
L1=1; %[H]
L2=1; %[H]
R1=2; %[ohm]
R2=2; %[ohm]
C1=1;  %[F]
C2=1;  %[F]
C3=1;  %[F]

% u1=15*sin(omega*t) 
% u2=5*sin(omega*t)

% amplitudes of AC sources
U1=15; %[V]
U2=5; %[V]

% reactances
XL1=omega*L1;
XL2=omega*L2;
XC1=1/(omega*C1);
XC2=1/(omega*C2);
XC3=1/(omega*C3);

% impedances
ZL1=j*XL1;
ZL2=j*XL2;
ZC1=-j*XC1;
ZC2=-j*XC2;
ZC3=-j*XC3;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A= [ZL1+R1+ZC2+ZC1  -ZC1     -ZC2;
        -ZC1     ZC1+R2+ZL2  -ZL2;
        -ZC2     -ZL2   ZC3+ZL2+ZC2];
    
b=[U1;-U1;-U2]; 

Iabc=A\b;

IL2=Iabc(2)-Iabc(3);
IC2=Iabc(1)-Iabc(3);

UL2=IL2*ZL2;
UC2=IC2*ZC2;

fprintf('\n**** Steady state analysis *****\n');
fprintf('|IL2|= %g , phase= %g�, IL2= %g %gj\n', abs(IL2), angle(IL2)*360/(2*pi), real(IL2), imag(IL2));
fprintf('|IC2|= %g , phase= %g�, IC2= %g %gj\n', abs(IC2), angle(IC2)*360/(2*pi), real(IC2), imag(IC2));
fprintf('|UL2|= %g , phase= %g�, UL2= %g %gj\n', abs(UL2), angle(UL2)*360/(2*pi), real(UL2), imag(UL2));
fprintf('|UC2|= %g , phase= %g�, UC2= %g %gj\n', abs(UC2), angle(UC2)*360/(2*pi), real(UC2), imag(UC2));