Try the following (note that m4 is not required):

dpic -v Escher.pic > Escher.svg

View the result in a browser.
