#define	lxmax	456
#define	XXenvvar	163
#define	Xlastsc	180
#define	Xlastenv	186
