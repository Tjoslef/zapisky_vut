// startPrint
// proměnná x je tu, ale je nedefinovaná
int x;
// extern znamená, že proměnná y je někde definovaná, tak ať si pro ni udělá místo
extern int y;
// stopPrint
