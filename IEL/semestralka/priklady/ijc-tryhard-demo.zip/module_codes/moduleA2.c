// startPrint
// static znamená něco jako private, tzn. že proměnná x je viditelná jen v tomto modulu
// ještě k tomu je globální, takže je nulovaná
// bohužel je tu static, takže ta v druhém modulu není vidět
static int x;

int mainA() {
    // proměnná x se použije z tohoto modulu, tedy x = 0
    return x;
}
// stopPrint

int main()
{
    printf("%d", mainA());
    return 0;
}
