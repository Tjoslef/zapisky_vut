// startPrint
// extern znamená, že proměnná x je někde definovaná, tak ať si pro ni udělá místo
extern int x;
// to stejné pro y
extern int y;
// našli jsme x, jeho hodnota je 34
int x = 34;
// našli jsme i y, jeho hodnota je 77
int y = 77;
// stopPrint
