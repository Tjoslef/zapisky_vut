// startPrint
// extern znamená, že proměnná x je někde definovaná, tak ať si pro ni udělá místo
extern int x;
// proměnná x je tu, a má hodnotu 55
int x = 55;
// stopPrint