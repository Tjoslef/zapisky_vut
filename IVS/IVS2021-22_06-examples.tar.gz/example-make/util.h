double square(double x);
