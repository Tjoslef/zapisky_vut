#include <math.h>

double square(double x) 
{
    return pow(x, 2);
}
