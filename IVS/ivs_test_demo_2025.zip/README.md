Ukazky lze prelozit pomoci:
```
cmake .
make
```
