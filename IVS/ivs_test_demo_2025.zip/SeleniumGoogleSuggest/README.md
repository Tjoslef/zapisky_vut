Ukazka muze byt prelozena a spustena pomoci:
```
mvn compile exec:java
```
Note: pro jiny operacni system nez linux budete potrebovat stahnout spravny chromedriver.
