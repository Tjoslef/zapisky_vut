#include "person.h"

int main() {
    Person person("Martin", 21);
    person.print();
    return 0;
}
